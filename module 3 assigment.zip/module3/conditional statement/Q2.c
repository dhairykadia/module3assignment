/*
2. Write a C program to read the value of an integer m and display the value of 
n is 1 when m is larger than 0, 0 when m is 0 and -1 when m is less than 0
*/

#include <stdio.h>

int main() 
{
    int a,b;
    
    printf("Enter the value of a: ");
    scanf("%d", &a);
    
    if (a > 0) 
	{
        b = 1;
    }
	else if (a == 0) 
	{
        b = 0;
    } 
	else 
	{
        b = -1;
    }
    
    printf("\nThe value of b is: %d", b);
    return 0;
}


