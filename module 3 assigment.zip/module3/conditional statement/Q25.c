/*
 Accept the input month number and print number of days in that
month.
*/

#include <stdio.h>

int isleapyear(int year) 
{
    if (year % 4 == 0) 
	{
        if (year % 100 == 0) 
		{
            if (year % 400 == 0) return 1;
            else return 0;
        } 
		else return 1;
    } 
	else return 0; 
}

int main() 
{
    int month, year;

    printf("enter year: ");
    scanf("%d", &year);

    printf("enter month number (1-12): ");
    scanf("%d", &month);

    switch (month) 
	{
        case 1:  // January
        case 3:  // March
        case 5:  // May
        case 7:  // July
        case 8:  // August
        case 10: // October
        case 12: // December
            printf("\n31 days");
            break;
        case 4:  // April
        case 6:  // June
        case 9:  // September
        case 11: // November
            printf("\n30 days");
            break;
        case 2:  // February
            if (isleapyear(year)) 
			{
                printf("\n29 days (leap year)");
            } 
			else 
			{
                printf("\n28 days");
            }
            break;
        default:
            printf("\ninvalid month number");
    }

    return 0;
}

