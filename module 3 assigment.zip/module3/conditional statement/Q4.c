/*
4. WAP to make simple calculator (operation include Addition, Subtraction, 
Multiplication, Division, modulo) using conditional statement
*/


#include <stdio.h>

int main() 
{
    char operator;
    int num1, num2, sum;

    printf("Enter an operator (+, -, *, /): ");
    scanf(" %c", &operator);

    printf("Enter first operands: ");
    scanf("%d",&num1);
    
    
    printf("Enter second operands: ");
    scanf("%d",&num2);

    if (operator == '+') 
	{
        sum = num1 + num2;
        printf("\n%d + %d = %d", num1, num2, sum);
    } 
	else if (operator == '-') 
	{
        sum = num1 - num2;
        printf("\n%d - %d = %d", num1, num2, sum);
    } 
	else if (operator == '*') 
	{
        sum = num1 * num2;
        printf("\n%d * %d = %d", num1, num2, sum);
    } 
	else if (operator == '/')  
	{ 
		sum = num1 / num2;
		printf("\n%d / %d = %d", num1, num2, sum);
    } 
    
	else 
	{
        printf("\nOperator is not correct");
    }

    return 0;
}

