// Accept month number and display month name

#include <stdio.h>

int main() 
{
    int month;

    printf("enter month number (1-12): ");
    scanf("%d", &month);

    switch (month) 
	{
        case 1:
            printf("\njanuary");
            break;
        case 2:
            printf("\nfebruary");
            break;
        case 3:
            printf("\nmarch");
            break;
        case 4:
            printf("\napril");
            break;
        case 5:
            printf("\nmay");
            break;
        case 6:
            printf("\njune");
            break;
        case 7:
            printf("\njuly");
            break;
        case 8:
            printf("\naugust");
            break;
        case 9:
            printf("\nseptember");
            break;
        case 10:
            printf("october");
            break;
        case 11:
            printf("\nnovember");
            break;
        case 12:
            printf("\ndecember");
            break;
        default:
            printf("\ninvalid month number");
    }

    return 0;
}

