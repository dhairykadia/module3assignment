//5. Check Number Is Positive or Negative

#include <stdio.h>
int main() 
{
    int number;

    printf("Enter a number: ");
    scanf("%d", &number);

    if (number > 0) 
	{
        printf("\n%d is positive", number);
    } 
	else if (number < 0) 
	{
        printf("\n%d is negative", number);
    } 
	else 
	{
        printf("\nThe number is zero");
    }

    return 0;
}

