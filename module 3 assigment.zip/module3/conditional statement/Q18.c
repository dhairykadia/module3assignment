// Write a C program to calculate profit and loss on a transaction.*/
//profit= sellingprice-costprice
//loss = costprice-selling price

#include<stdio.h>
int main()
{
	int s_price,c_price,profit,loss;
	
	printf("Enter your selling price: ");
	scanf("%d",&s_price);
	
	printf("Enter your Cost price: ");
	scanf("%d",&c_price);
	
	profit = s_price-c_price;

	loss = c_price-s_price;
	
	
	if (profit > loss)
	{
		printf("\nThe profit of the product : %d ",profit);
		printf("\n/*good business mind*/");
		printf("\nyou are having good amount of transaction.");
	}
	else if (profit == loss)
	{
		printf("\n you got neither profit nor loss.");
	}
	else
	{
		printf("\nThe loss of the product : %d ",loss);
		printf("\nyou are having a loss");
	}
	
	return 0;
	
}
