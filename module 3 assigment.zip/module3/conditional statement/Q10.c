/*
10. WAP to check whether a number is negative, positive or zero.
*/

#include <stdio.h>
int main() 
{
    int number;
    printf("Enter a number: ");
    scanf("%d", &number);

    if (number > 0) 
	{
        printf("\npositive number", number);
    } 
	else if (number < 0) 
	{
        printf("\nnegative number", number);
    } 
	else 
	{
        printf("\nnumber is zero");
    }
    return 0;
}



