/*
3. WAP to take 10 no. Input from user find out below values
a. How many Even numbers are there
b. How many odd numbers are there
c. Sum of even numbers
d. Sum of odd numbers
*/

#include <stdio.h>

int main() 
{
    int i,number[10],evenCount=0,oddCount=0,sumEven=0,sumOdd=0;

    printf("\nenter numbers:");
    for (i = 0; i < 10; i++) 
	{
        printf("\nenter number %d: ", i + 1);
        scanf("%d", &number[i]);

        if (i % 2 == 0) 
		{
            evenCount++;
            sumEven += number[i];
        } 
		else 
		{
            oddCount++;
            sumOdd += number[i];
        }
    }

    printf("\neven numbers: %d", evenCount);
    printf("\nodd numbers: %d", oddCount);
    printf("\nSum of even numbers: %d", sumEven);
    printf("\nSum of odd numbers: %d", sumOdd);

    return 0;
}

