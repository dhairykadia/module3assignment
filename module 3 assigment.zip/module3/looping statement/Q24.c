//24. 1 + 2 + 3 + 4 + 5 + ... + n


#include <stdio.h>

int main() 
{
    int n,i,sum = 0;

    printf("Enter the value  n: ");
    scanf("%d", &n);

    for (i = 1; i <= n; ++i) 
	{
        sum += i;
    }

    printf("\nSum = 1 + 2 + 3 + ... + %d = %d", n, sum);

    return 0;
}


