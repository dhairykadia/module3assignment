//2. WAP to accept 5 numbers from user and display all numbers

#include <stdio.h>

int main() 
{
    int i,numbers[5];

    for (i = 0; i < 5; i++) 
	{
        printf("Enter number %d: ", i+1);
        scanf("%d", &numbers[i]);
    }
	printf("\nenter the numbers:");
    for (i = 0; i < 5; i++) 
	{
        printf("\n%d", numbers[i]);
    }
    return 0;
}

