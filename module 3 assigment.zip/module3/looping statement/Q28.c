// 1 2 3 6 9 18 27 54...


#include<stdio.h>
int main()
{
	int range,i;
	int terms = 1;
	printf("\nenter the range = ");
	scanf("%d",&range);
	for(i=0;i<range;i++)
	{
		printf("%d\t",terms);
		if(i%2==0)
		{
			terms = terms * 2;
		}
		else
		{
			terms = terms * 3;
		}
	}
	return 0;
}
