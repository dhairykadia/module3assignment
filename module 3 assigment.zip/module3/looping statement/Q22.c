/*
22. Accept 3 numbers from user using while loop and check each numbers 
palindrome
*/

#include <stdio.h>
int main() 
{
    int num, reverse=0, rem,count=1;

    while (count <= 3) {
        printf("\nenter number %d: ",count);
        scanf("%d", &num);

        int copy = num;
        
        while (num != 0) 
		{
            rem = num % 10;
            reverse = reverse * 10 + rem;
            num /= 10;
        }

        if (copy == reverse) 
		{
            printf("\n%d palindrome number", copy);
        } 
		else 
		{
            printf("\n%d not palindrome", copy);
        }

        count++;
    }

    return 0;
}


