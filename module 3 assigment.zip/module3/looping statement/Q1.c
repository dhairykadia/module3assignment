//1. WAP to print 972 to 897 using for loop

#include <stdio.h>

int main() 
{
	int i;
    for (i = 972;i >= 897;i--) 
	{
        printf("\n%d ", i);
    }
    return 0;
}
