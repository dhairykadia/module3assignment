//16.Calculate the Sum ofNatural Numbers Using the While Loop


#include<stdio.h>

int main() 
{
    int n, sum = 0, i = 1;

    printf("enter number: ");
    scanf("%d", &n);

    while (i <= n) 
	{
        sum += i;
        i++;
    }

    printf("\nsum of natural numbers %d = %d", n, sum);

    return 0;
}
