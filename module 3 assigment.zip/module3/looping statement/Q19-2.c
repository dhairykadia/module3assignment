/*
A
B C
D E F
G H I J
K L M N O
*/


#include<stdio.h>

int main() 
{
    int i, j, rows = 5;  
    char c1='A';  
    for (i = 0; i < rows; i++) 
	{
        for (j = 0; j <= i; j++)
		{
            printf("%c ", c1);
            c1++; 
        }
        printf("\n");  
    }

    return 0;
}


