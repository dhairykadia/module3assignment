/*
 C Program to Reverse a Number Using FOR Loop
Series Program:
*/

#include <stdio.h>

int main()
{
    int num, reversed = 0;

    printf("enter an integer: ");
    scanf("%d", &num);

    int temp = num;

    for (; temp != 0; temp /= 10) 
	{
        int digit = temp % 10;  
        reversed = reversed * 10 + digit;  
    }

    printf("\nreversed number: %d", reversed);

    return 0;
}

