// WAP to print Fibonacci series up to given numbers

#include <stdio.h>

int main() 
{
    int limit; 
    int a = 0, b = 1, c;
	
    printf("fibonacci series: ");
    scanf("%d", &limit);

    printf("\nfibonacci series up to :", limit);
    
    if (limit >= 0) 
	{
		printf("%d ", a);
	}
	if (limit >= 1)
	{
		printf("%d ", b);
	}
   
   	while (1) 
   	{
        c = a + b;
        if (c > limit) break; 
        printf("%d ", c);
        a = b;
        b = c;
    }

    printf("\n");
    return 0;
}

