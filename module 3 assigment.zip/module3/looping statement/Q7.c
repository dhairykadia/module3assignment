/*
 WAP to print number in reverse order e.g.: number = 64728 ---> reverse = 
82746
*/

#include <stdio.h>

int main() 
{
    int number, reversed = 0, original;
    
    printf("Enter a number: ");
    scanf("%d", &number);
    
    original = number; 
    
    
    while (number != 0) 
	{
        int digit = number % 10; 
        reversed = reversed * 10 + digit; 
        number /= 10; 
    }
    
    printf("\nreversed number of %d is %d", original, reversed);
    
    return 0;
}

