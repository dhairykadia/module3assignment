/*
Calculate 5 numbers from user and calculate number of even and odd using 
of while loop
*/

#include <stdio.h>

int main() 
{
    int num;
    int i = 0; 
    int evenCount = 0;
    int oddCount = 0; 
    while (i < 5) 
	{
        printf("Enter a number: ");
        scanf("%d", &num);

        if (num % 2 == 0) 
		{
            evenCount++;
        } 
		else 
		{
            oddCount++;
        }

        i++; 
    }

    printf("\nnumber of even numbers: %d", evenCount);
    printf("\nnumber of odd numbers: %d", oddCount);

    return 0;
}

