//13. calculate the Factorial of a Given Number using while loop


#include<stdio.h>;
int main()
{
	int num,fact=1,i;
	printf("\nenter a number = ");
	scanf("%d",&num);
	
	for(i=1;i<=num;i++)
	{
		fact=fact*i;
	}
	printf("\nfactorial of %d is %d",num,fact);
	return 0;	
}
