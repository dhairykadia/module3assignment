/*7. Find area of Rectangle Formula : A=wl*/

#include<stdio.h>
int main()
{
	
	int area,w,l;
	printf("enter the width of rectangle =");
	scanf("%d",&w);
	printf("enter the length of rectangle =");
	scanf("%d",&l);
	
	area=w*l;
	printf("area of the rectangle = %d",area);
	
	return 0;
	
}
