// Accept monthly salary from the user and deduct 10% insurance premium,10% loan installment find out of remaining salary.

#include<stdio.h>
int main() 
{
    float m_salary,insurance_premium,loan_installment,remaining_salary;

    printf("Enter monthly salary: ");
    scanf("%f",&m_salary);

    insurance_premium = 0.10 * m_salary;

    loan_installment = 0.10 * m_salary;

    remaining_salary = m_salary - insurance_premium - loan_installment;

    printf("\nMonthly Salary: %.2f\n", m_salary);
    
    printf("Insurance Premium (10%%): %.2f\n", insurance_premium);
    printf("Loan Installment (10%%): %.2f\n", loan_installment);
    
	printf("Remaining Salary after deductions: %.2f\n", remaining_salary);

    return 0;
}
