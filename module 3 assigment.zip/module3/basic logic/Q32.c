//Accept 2 numbers and find out its sum check it size
#include <stdio.h>

