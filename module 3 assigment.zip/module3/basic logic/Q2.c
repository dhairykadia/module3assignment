/*2. Write a program to make Simple calculator (to make addition, subtraction,
multiplication, division and modulo)*/

#include<stdio.h>
int main()
{
		int a,b,add,sub,mul,mod,div;
		printf("\nenter a number of a = ");
		scanf("%d",&a);
		printf("\nenter a number of b = ");
		scanf("%d",&b);
		
		add = a + b;
		printf("\n addition = %d",add);
		
		sub = a - b;
		printf("\n subtaction = %d",sub);
		
		mul = a * b;
		printf("\n multiplication = %d",mul);
		
		div = a / b;
		printf("\n divison = %d",div);
		
		mod = a % b;
		printf("\n modulo = %d",mod);
		
		return 0;
}

