/*. Display This Information using printf
a. Your Name
b. Your Birth date
c. Your Age
d. Your Address
*/

#include<stdio.h>
int main()
{
	int a1,a2,a43,a4;
	printf("\nenter your name = dhairy kadia");
	
	printf("\nenter your birth date = 10-04-2004");
	
	printf("\nenter your age = 20");
	
	printf("\nenter your address = xyz");
	
	return 0;
	
	
}

