//Calculate person�s insurance premium based on salary

#include<stdio.h>
void main()
{
	long int cage,cwage,year;
	
	printf("\ncurrent wage = ");
	scanf("%ld",&cwage);
	
	printf("\nnumber of the year retirement = ");
	scanf("%ld",&year);
	
	cage = cwage * year;
	
	printf("insurance covrage  = %d",cage);
	 
	return 0;
}
