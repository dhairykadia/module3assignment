//Convert minutes into seconds and hours
#include<stdio.h>

int main() 
{
    float minutes, seconds, hours;

    printf("\nEnter the number of minutes = ");
    scanf("%f", &minutes);

    // Calculate seconds
    seconds = minutes * 60; //75min*60sec = 4500

    // Calculate hours
    hours = minutes / 60; // 75min/60sec = 1.5

    printf("%f minutes is equal to:\n", minutes);
    printf("%f seconds\n", seconds);
    printf("%f hours\n", hours);

    return 0;
}
