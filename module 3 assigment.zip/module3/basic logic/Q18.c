//Calculate person�s Annual salary

#include<stdio.h>
int main()
{
	int monthS,annualS;
	
	printf("enter monthly salary: ");
	scanf("%d",&monthS);
	
	annualS = monthS * 12;
	
	printf("\nannula salary is %d",annualS);
	
	return 0;
}
