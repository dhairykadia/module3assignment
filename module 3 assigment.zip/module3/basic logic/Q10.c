/*10.find the area of a rectangular prism formula : A=2(wl+hl+hw)*/ 

#include<stdio.h>
int main()
{
	int w,l,h,a;
	
	printf("enter whith = ");
	scanf("%d",&w);
	printf("enter hight = ");
	scanf("%d",&h);
	printf("enter lengh = ");
	scanf("%d",&l);
	
	a = 2 * w * l + h * l  + h * w;
	
	printf("\narea of rectangular prism = %d",a);
	
	return 0;
}
