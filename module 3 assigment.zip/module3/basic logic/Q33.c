//C Program to Read Integer and Print First Three Powers (N^1, N^2, N^3)

#include <stdio.h>

int main() 
{
    int number;
    printf("Enter an integer: ");
    scanf("%d", &number);

    int power1 = number;
    int power2 = number * number;
    int power3 = number * number * number;

    printf("\nFirst three power %d :", number);
    printf("\n%d^1 = %d", number, power1);
    printf("\n%d^2 = %d", number, power2);
    printf("\n%d^3 = %d", number, power3);

    return 0;
}
