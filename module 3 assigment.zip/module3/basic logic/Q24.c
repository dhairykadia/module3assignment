//Accept 5 employees name and salary and count average and total salary

#include<stdio.h>
int main()
{
	int a1,b2,c3,d4,e5, Tsalary;
	char n1[10],n2[10],n3[10],n4[10],n5[10];
	float Average;
	
	printf("Enter name of a is n1 : ");
	scanf("%s",&n1);
	printf("Enter salary of a : ");
	scanf("%d",&a1);
	
	printf("Enter name of b is n2 : ");
	scanf("%s",&n2);
	printf("Enter salary of b : ");
	scanf("%d",&b2);
	
	printf("Enter name of c  is n3: ");
	scanf("%s",&n3);
	printf("Enter salary of c : ");
	scanf("%d",&c3);
	
	printf("Enter name of d  is n4: ");
	scanf("%s",&n4);
	printf("Enter salary of d : ");
	scanf("%d",&d4);
	
	printf("Enter name of e  is n5 : ");
	scanf("%s",&n5);
	printf("Enter salary of 5 : ");
	scanf("%d",&e5);
	
	Tsalary=a1+b2+c3+d4+e5;
	printf("\nTotal Salary is : %d",Tsalary);
	
	Average= (Tsalary / 5 );
	printf("\nYour average value is: %.2f ", Average);
	return 0;
}
