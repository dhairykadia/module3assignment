//Accept 5 expense from user and find average of expense
#include <stdio.h>

int main() {
    float expense[5], t_expense = 0, avg_Expense;
    int i;

    // Input 5 expenses
    for (i = 0; i < 5; i++) 
	{
    printf("Enter expense %d: ", i + 1);
    scanf("%f", &expense[i]);
    t_expense += expense[i]; // Calculate total expense
    }

    // Calculate average expense
    avg_Expense = t_expense / 5;

    // Display results
    printf("Total expense: %2f\n", t_expense);
    printf("Average expense: %2f\n", avg_Expense);

    return 0;
}
