/*4. Find Area of Square formula : a = a2*/

#include<stdio.h>
int main()
{
	int side,area;
	printf("area of sqare a formula  = ");
	scanf("%d",&side);
	
	area=side*side;
	printf("area of sqare %d:%d",side,area);
	
	return 0;
}
