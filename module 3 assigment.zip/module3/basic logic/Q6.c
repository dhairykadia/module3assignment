/*6. Find area of Triangle Formula : A = 1/2 � b � h*/

#include<stdio.h>
int main()
{
	
	int area,b,h;
	printf("enter the tringle =");
	scanf("%d",&b);
	printf("enter the tringle =");
	scanf("%d",&h);
	
	area=b*h/2;
	printf("area of the tringle = %d",area);
	
	return 0;
	
}
