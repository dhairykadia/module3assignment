/*12.Accept number of students from user. I need to give 5 apples to each
student. How many apples are required?*/

#include<stdio.h>
int main()
{
	int stud;
	printf("\nnumber od student = ");
	scanf("%d",&stud);
	
	printf("number of apple = %d",5*stud);
	
	return 0;
}


