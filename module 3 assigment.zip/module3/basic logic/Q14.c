/* 14.Find ascii value of given number */

#include <stdio.h>
int main() 
{  
    int num;
    printf("Enter a number: ");
    scanf("%d", &num); 
    
    printf("ASCII value of  %c", num);
    
    return 0;
}
