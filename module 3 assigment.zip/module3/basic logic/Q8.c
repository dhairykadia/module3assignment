/*8. Find circumference of Rectangle formula : C = 4 * a*/

#include<stdio.h>
int main()
{
	
	int a,c;
	printf("enter the rectangle a  =");
	scanf("%d",&a);
	
	c=4*a;
	printf("circumference of the rectangle = %d",c);

	return 0;
	
}
