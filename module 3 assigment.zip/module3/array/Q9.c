// WAP to show difference between Structure and Union.

#include <stdio.h>

struct Student 
{
    char name[50];
    int roll_no;
    float marks;
};

union Data 
{
    int i;
    float f;
    char c;
};

int main() 
{
    struct Student student1;
    strcpy(student1.name, "dhairy");
    student1.roll_no = 101;
    student1.marks = 85.5;

    printf("\nStructure:\n");
    printf("Name: %s\n", student1.name);
    printf("Roll No: %d\n", student1.roll_no);
    printf("Marks: %.2f\n", student1.marks);

    union Data data;

    data.i = 10;
    printf("\nUnion (int): %d\n", data.i);

    data.f = 3.14;
    printf("Union (float): %.2f\n", data.f);

    data.c = 'A';
    printf("Union (char): %c\n", data.c);

    return 0;
}
