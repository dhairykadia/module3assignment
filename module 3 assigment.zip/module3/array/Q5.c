/* WAP to take two Array input from user and sort them in ascending or 
descending order as per user�s choice
*/

#include <stdio.h>

void sortarray(int arr[], int size, int ascending) 
{
    int i, j, temp;
    for (i = 0; i < size - 1; i++) 
	{
        for (j = i + 1; j < size; j++) 
		{
            if ((ascending && arr[i] > arr[j]) || (!ascending && arr[i] < arr[j])) 
			{
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void printarray(int arr[], int size, int i) 
{
    for (i = 0; i < size; i++) 
	{
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() 
{
    int size1, size2, i;
    int order;

    printf("enter the number of elements in the first array: ");
    scanf("%d", &size1);
    int array1[size1];
    printf("\nenter the elements of the first array:");
    for (i = 0; i < size1; i++) 
	{
        scanf("%d", &array1[i]);
    }

    printf("enter the number of elements in the second array: ");
    scanf("%d", &size2);
    int array2[size2];
    printf("\nenter the elements of the second array:");
    for (i = 0; i < size2; i++) 
	{
        scanf("%d", &array2[i]);
    }

    printf("enter 1 for ascending order or 2 for descending order: ");
    scanf("%d", &order);

    sortarray(array1, size1, order == 1);
    printf("sorted first array: ");
    printarray(array1, size1);

    sortArray(array2, size2, order == 1);
    printf("sorted second array: ");
    printarray(array2, size2);

    return 0;
}

