//10. Write a program in C to extract a substring from a given string

#include <stdio.h>
#include <string.h>

int main() 
{
  char str[100], substr[100];
  int start, end;

  printf("Enter a string: ");
  gets(str); 
  
  printf("Enter the starting position of the substring: ");
  scanf("%d", &start);

  printf("Enter the ending position of the substring: ");
  scanf("%d", &end);

  if (start < 0 || end >= strlen(str) || start > end) 
  {
    printf("Invalid starting or ending positions.\n");
    return 1;
  }

  int i, j = 0;
  for (i = start; i <= end; i++) 
  {
    substr[j] = str[i];
    j++;
  }
  substr[j] = '\0'; 
  
  printf("Extracted substring: %s\n", substr);

  return 0;
}
