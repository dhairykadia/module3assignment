//5. Write a program in C to compare two strings without using string library functions.

#include <stdio.h>

int main() 
{
  char str1[100], str2[100];
  int i = 0;
  int areEqual = 1;
  
  printf("Enter the first string: ");
  gets(str1);
  
  printf("Enter the second string: ");
  gets(str2);
  
  while (str1[i] != '\0' && str2[i] != '\0') 
  {
    if (str1[i] != str2[i]) 
	{
      areEqual = 0; 
      break; 
    }
    i++;
  }

  if (areEqual && (str1[i] == '\0' && str2[i] == '\0')) 
  {
    printf("The strings are equal.\n");
  } 
  else 
  {
    printf("The strings are not equal.\n");
  }

  return 0;
}
