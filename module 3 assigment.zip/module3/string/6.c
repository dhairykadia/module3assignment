//6. Write a program in C to count the total number of alphabets, digits and special characters in a string.

#include <stdio.h>

int main() 
{
  char str[100];
  int i, alphabetCount = 0, digitCount = 0, specialCharCount = 0;

  printf("Enter a string: ");
  gets(str);
  
  for (i = 0; str[i] != '\0'; i++) 
  {
    if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z')) 
	{
      alphabetCount++;
    } 
	else if (str[i] >= '0' && str[i] <= '9') 
	{
      digitCount++;
    } 
	else 
	{
      specialCharCount++;
    }
  }

  printf("Alphabets: %d\n", alphabetCount);
  printf("Digits: %d\n", digitCount);
  printf("Special Characters: %d\n", specialCharCount);

  return 0;
}
