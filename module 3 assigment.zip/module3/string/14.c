//14. Write a program in C to combine two strings manually

#include <stdio.h>

int main() 
{
  char str1[100], str2[100], combinedStr[200]; 
  int i, j;

  printf("Enter the first string: ");
  gets(str1); 

  printf("Enter the second string: ");
  gets(str2);

  for (i = 0; str1[i] != '\0'; i++) 
  {
    combinedStr[i] = str1[i];
  }

  for (j = 0; str2[j] != '\0'; j++) 
  {
    combinedStr[i + j] = str2[j];
  }

  combinedStr[i + j] = '\0';

  printf("Combined string: %s\n", combinedStr);

  return 0;
}
