//8. Write a program in C to count the total number of vowels or consonants in a string

#include <stdio.h>
#include <ctype.h> 

int main() 
{
  char str[100];
  int i, vowelCount = 0, consonantCount = 0;

  printf("Enter a string: ");
  gets(str); 
  
  for (i = 0; str[i] != '\0'; i++) 
  {
    char ch = tolower(str[i]); 

    if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') 
	{
      vowelCount++;
    } 
	else if ((ch >= 'a' && ch <= 'z') && (ch != 'a' && ch != 'e' && ch != 'i' && ch != 'o' && ch != 'u')) 
	{
      consonantCount++;
    }
  }

  printf("Vowel Count: %d\n", vowelCount);
  printf("Consonant Count: %d\n", consonantCount);

  return 0;
}
